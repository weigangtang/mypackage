from setuptools import setup

setup(name='my-first-package',
      version='0.1',
      description='Test',
      author='Victor Tang',
      author_email='tangw5@mcmaster.ca',
      license='MIT',
      packages=['mypack'],
      zip_safe=False)